package app.mymusic.domain.entities.enums;

public enum  ArtistNameEnum {
    QUEEN,
    METALLICA,
    MADONNA
}
