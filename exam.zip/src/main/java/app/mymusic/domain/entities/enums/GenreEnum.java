package app.mymusic.domain.entities.enums;

public enum GenreEnum {
    POP,
    ROCK,
    METAL,
    OTHER
}
